export interface Experience {
  role: string;
  company: string;
  companyUrl?: string;
  type: 'Full-time' | 'Internship' | 'Part-time' | 'Freelance' | 'Volunteer';
  period: string;
  bullets: string[];
  tech: string[];  // Shown as subtle tags — this replaces the standalone skills section
}

export const EXPERIENCE: Experience[] = [
  {
    role: "SOK MENTEE",
    company: "KDE",
    companyUrl: "https://kde.org/",
    type: "Internship",
    period: "Jan 2026 - Mar 2026",
    bullets: [
      "Worked on mentorship.kde.org, a site visited by more than millions.",
      "Restructured the internal configurations and reinvented the design.",
      "Improved onbaording expericne for new candidates aiming to join kde community",
    ],
    tech: ["HuGO", "GO"],
  },
  {
    role: "Backend AI Develepor",
    company: "FlyRank AI",
    companyUrl: "https://flyrank.ai/",
    type: "Internship",
    period: "Jun 2026 - Aug 2026",
    bullets: [
      "REPLACE_ME: What you built.",
      "REPLACE_ME: Second bullet.",
    ],
    tech: ["React", "Node.js", "REPLACE_ME"],
  },
  {
    role: "OSS contributor",
    company: "Insketor-gadget",
    type: "Volunteer",
    period: "Nov 2025 — Present",
    bullets: [
      "REPLACE_ME: What you contributed.",
    ],
    tech: ["REPLACE_ME"],
  },
];
